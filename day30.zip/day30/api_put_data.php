<?php
<input type="text" id="id" placeholder="Enter ID">
<input type="text" id="name" placeholder="Enter Name">

<button onclick="updateData()">Update</button>

<script>
function updateData(){

let id = document.getElementById("id").value;
let name = document.getElementById("name").value;

fetch("update.php",{
    method:"PUT",
    headers:{
        "Content-Type":"application/json"
    },
    body: JSON.stringify({
        id:id,
        name:name
    })
})
.then(res=>res.json())
.then(data=>console.log(data));

}
</script>
?>