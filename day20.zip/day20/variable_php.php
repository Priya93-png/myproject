String
<?php
$name = "Priya";
var_dump($name);
?>

Integer
<?php
$a = 100;
var_dump($a);
?>

Float(Double)
<?php
$b = 10.5;
var_dump($b);
?>

Boolean
<?php
$isActive = true;
var_dump($isActive);
?>

Array
<?php
$colors = array("Red", "Green", "Blue");
var_dump($colors);
?>

Object
<?php
class Car {
  public $name = "BMW";
}
$obj = new Car();
var_dump($obj);
?>

NULL
<?php
$x = null;
var_dump($x);
?>