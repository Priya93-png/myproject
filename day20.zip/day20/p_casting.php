String → Int
<?php
$a = "100";
$b = (int)$a;

var_dump($b);
?>

Float → Int
<?php
$x = 10.8;
$y = (int)$x;

var_dump($y);
?>

Int → String
<?php
$num = 50;
$str = (string)$num;

var_dump($str);
?>

Value → Boolean
<?php
$a = 0;
$b = (bool)$a;

var_dump($b);
?>

Array Casting
<?php
$a = "hello";
$arr = (array)$a;

print_r($arr);
?>