for Loop

<?php
for ($i = 1; $i <= 5; $i++) {
    echo $i . "<br>";
}
?>

while Loop

<?php
$i = 1;
while ($i <= 5) {
    echo $i . "<br>";
    $i++;
}
?>

do...while Loop

<?php
$i = 1;
do {
    echo $i . "<br>";
    $i++;
} while ($i <= 5);
?>

foreach Loop

<?php
$colors = ["red", "green", "blue"];

foreach ($colors as $color) {
    echo $color . "<br>";
}
?>
