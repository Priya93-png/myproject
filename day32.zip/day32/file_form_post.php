<!DOCTYPE html>
<html>
<head>
<title>HTML + PHP Same File</title>
</head>
<body>

<?php
if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];

    echo "Name: " . $name . "<br>";
    echo "Email: " . $email;
}
?>

<form method="POST">

Name:
<input type="text" name="name"><br><br>

Email:
<input type="email" name="email"><br><br>

<input type="submit" name="submit" value="Submit">

</form>

</body>
</html>