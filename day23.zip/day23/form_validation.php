<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
</head>
<body>

<form method="POST" enctype="multipart/form-data">

    First Name:
    <input type="text" name="name"><br><br>

    Second Name:
    <input type="text" name="secondname"><br><br>

    Email:
    <input type="text" name="email"><br><br>

    Age:
    <input type="number" name="age"><br><br>

    Password:
    <input type="password" name="password"><br><br>

    submit:
    <input type="submit" name="submit" value="Register">

</form>

</body>
</html>