<!DOCTYPE html>
<html>
<head>
    <title>My Website</title>
    <style>
        body {
            margin: 0;
            font-family: Arial;
        }

        nav {
            background-color: #333;
            padding: 12px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
            font-weight: bold;
        }

        nav a:hover {
            color: yellow;
        }
    </style>
</head>
<body>

<nav>
    <a href="home.php">Home</a>
    <a href="events.php">Events</a>
    <a href="register.php">Register</a>
    <a href="contact.php">Contact</a>
</nav>