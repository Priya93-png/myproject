<?php
echo $_SERVER["PATH"];echo "<br>";
//print_r($_SERVER);
session_start();
$_SESSION["id"]=45;
echo $_SESSION["id"];

$_SESSION["id"]="";
echo $_SESSION["id"];


?>