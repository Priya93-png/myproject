<?php
$fname=$_REQUEST["first_name"];
$sname=$_REQUEST["second_name"];
$pass_word=$_REQUEST["pwd"];
$email=$_REQUEST["Email"];
$mobile_no=$_REQUEST["mobile_number"];
$ima_name=$_FILES["pro_image"]["name"]; //pro_image=["name=>]
$ima_size=$_FILES["pro_image"]["size"];
$ima_type=$_FILES["pro_image"]["type"];
$local_path=$_FILES["pro_image"]["tem_name"];

echo($ima_name);echo "<br>";
echo($ima_size);echo "<br>";
echo($ima_type);echo "<br>";
echo($local_path);echo "<br>";echo "<br>";

echo($fname);echo "<br>";
echo($sname);echo "<br>";
echo($pass_word);echo "<br>";
echo($email);echo "<br>";
echo($mobile_no);echo "<br>";
$destination_folder="img/";

if(move_uploaded_file($local_path,$destination_folder.$ima_name)){
    echo "done";
}

?>
