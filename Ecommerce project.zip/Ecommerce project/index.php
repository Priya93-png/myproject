<?php include 'header.php'; ?>

<div class="products">

<?php
$result = $conn->query("SELECT * FROM products");

while($row = $result->fetch_assoc()) {
?>

<div class="card product">
    <img src="images/<?php echo $row['image']; ?>" width="150">
    <h3><?php echo $row['name']; ?></h3>
    <p>₹<?php echo $row['price']; ?></p>

    <a href="add_to_cart.php?id=<?php echo $row['id']; ?>">
        <button>Add to Cart</button>
    </a>
</div>

<?php } ?>

</div>

<?php include 'footer.php'; ?>