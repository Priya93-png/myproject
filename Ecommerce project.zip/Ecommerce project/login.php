<?php include 'db.php'; ?>

<form method="post">
    <input type="text" name="username" placeholder="Username"><br>
    <input type="password" name="password" placeholder="Password"><br>
    <button name="login">Login</button>
</form>

<?php
if(isset($_POST['login'])) {

$username = $_POST['username'];
$password = $_POST['password'];

$result = $conn->query("SELECT * FROM users WHERE username='$username' AND password='$password'");

if($result->num_rows > 0) {
    $_SESSION['user'] = $username;
    header("Location: index.php");
} else {
    echo "Invalid login";
}
}
?>