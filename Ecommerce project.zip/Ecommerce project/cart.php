<?php include 'header.php'; ?>

<h2>Your Cart</h2>

<?php
if(isset($_SESSION['cart'])) {

foreach($_SESSION['cart'] as $id) {

$result = $conn->query("SELECT * FROM products WHERE id=$id");
$row = $result->fetch_assoc();
?>

<div>
    <h3><?php echo $row['name']; ?></h3>
    <p>₹<?php echo $row['price']; ?></p>
</div>

<?php } } else {
    echo "Cart is empty";
}
?>

<?php include 'footer.php'; ?>