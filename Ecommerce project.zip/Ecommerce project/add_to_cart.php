<?php
include 'db.php';

$id = $_GET['id'];

if(!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$_SESSION['cart'][] = $id;

header("Location: cart.php");
?>