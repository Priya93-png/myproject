<?php
$conn = new mysqli("localhost", "root", "Priya@1993", "ecommerce_full");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();
?>