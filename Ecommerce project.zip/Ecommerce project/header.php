<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>Ecommerce</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>My Shop</h1>

<div class="search-box">
  <input type="text" id="search" placeholder="Search products..." onkeyup="searchProduct()">
  <span>🔍</span>
</div>

    <nav>
        <a href="index.php">Home</a>
        <a href="cart.php">Cart 🛒 (<span id="count">0</span>)</a>

        <?php if(isset($_SESSION['user'])) { ?>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
        <?php } ?>
    </nav>
</header>
</body>
<script src="main.js"></script>
</html>