<footer>
    <p>© 2026 My Ecommerce</p>
</footer>
<script>
let cart = [];

function addToCart(product) {
    cart.push(product);
    document.getElementById("count").innerText = cart.length;
}

function searchProduct() {
    let input = document.getElementById("search").value.toLowerCase();
    let cards = document.querySelectorAll(".card");

    cards.forEach(card => {
        let text = card.innerText.toLowerCase();
        card.style.display = text.includes(input) ? "block" : "none";
    });
}
</script>
</body>
</html>