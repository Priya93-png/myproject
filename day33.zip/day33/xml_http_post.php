<?php
if(isset($_POST['name'])){
    $name = $_POST['name'];
    echo "Hello " . $name;
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>XML HTTP POST</title>
</head>
<body>

<h2>XMLHttpRequest POST Example</h2>

Name :
<input type="text" id="name">
<button onclick="sendData()">Send</button>

<p id="result"></p>

<script>

function sendData(){

    var name = document.getElementById("name").value;

    var xhr = new XMLHttpRequest();
    xhr.open("POST","xml_http_post.php",true);
    xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");

    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && xhr.status == 200){
            document.getElementById("result").innerHTML = xhr.responseText;
        }
    };

    xhr.send("name="+name);
}

</script>

</body>
</html>