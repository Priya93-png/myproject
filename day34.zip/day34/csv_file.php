<?php

$filename = "student.csv";

// file open
$file = fopen($filename, "w");

// header row
fputcsv($file, array("ID","Name","Age"));

// data rows
fputcsv($file, array("1","Arun","20"));
fputcsv($file, array("2","Priya","21"));
fputcsv($file, array("3","Ravi","22"));

// file close
fclose($file);

echo "CSV file created successfully";

?>