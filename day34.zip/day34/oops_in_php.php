<?php

class Student
{
    public $name;        // public variable
    private $age;        // private variable
    protected $course;   // protected variable

    // set methods
    public function putName($n)
    {
        $this->name = $n;
    }

    public function putAge($a)
    {
        $this->age = $a;
    }

    public function putCourse($c)
    {
        $this->course = $c;
    }

    // get methods
    public function getName()
    {
        return $this->name;
    }

    public function getAge()
    {
        return $this->age;
    }
}

class Child extends Student
{
    public function showCourse()
    {
        echo "Course: " . $this->course;
    }
}

$obj = new Child();

$obj->putName("Priya");
$obj->putAge(20);
$obj->putCourse("PHP");

echo "Name: " . $obj->getName();
echo "<br>";
echo "Age: " . $obj->getAge();
echo "<br>";

$obj->showCourse();

?>