<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "test_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="backup.csv"');

$output = fopen("php://output", "w");

$sql = "SELECT * FROM student";
$result = $conn->query($sql);

$header = array("ID","Name","Age","Course");
fputcsv($output, $header);

while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}

fclose($output);
$conn->close();
?>