<?php

// Function to add two numbers
function addNumbers($a, $b) {
    $sum = $a + $b;
    return $sum;
}

// Function to display a name
function showName($name) {
    echo "Name: " . $name . "<br>";
}

// Calling the functions
$result = addNumbers(10, 5);
echo "Sum: " . $result . "<br>";

showName("Priya");

?>