<?php
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $name = $_POST['name'];
    $department = $_POST['department'];
    $date = $_POST['date'];

    echo "<h3>Conduct Details</h3>";
    echo "Name : " . $name . "<br>";
    echo "Department : " . $department . "<br>";
    echo "Date : " . $date . "<br>";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Conduct Form</title>
</head>
<body>

<h2>Conduct Form</h2>

<form method="post" action="">
Name:
<input type="text" name="name" required>
<br><br>

Department:
<input type="text" name="department" required>
<br><br>

Date:
<input type="date" name="date" required>
<br><br>

<input type="submit" value="Submit">

</form>

</body>
</html>