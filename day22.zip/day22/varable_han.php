🔹 1. Checking if Variable Exists — isset()

<?php
$name = "Ravi";

if (isset($name)) {
    echo "Variable exists";
}
?>

🔹 2. Checking Empty — empty()

<?php
$value = "";

if (empty($value)) {
    echo "Value is empty";
}
?>

🔹 3. Remove Variable — unset()

<?php
$name = "Anu";
unset($name);

echo $name; 
?>

🔹 4. Get Variable Type — gettype()
<?php
$num = 100;
echo gettype($num);
?>

🔹 5. echo — Display Output

<?php
echo "Hello World";
?>
🔹 6. if Statement
<?php
$age = 20;

if ($age >= 18) {
    echo "Eligible to vote";
}
?>


🔹 7. if...else Statement
<?php
$age = 16;

if ($age >= 18) {
    echo "Adult";
} else {
    echo "Minor";
}
?>

🔹 8. if...elseif...else

<?php
$marks = 75;

if ($marks >= 90) {
    echo "Grade A";
} elseif ($marks >= 60) {
    echo "Grade B";
} else {
    echo "Grade C";
}
?>
