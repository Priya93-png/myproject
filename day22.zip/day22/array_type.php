🔷 implode() Function

<?php
$colors = ["Red", "Green", "Blue"];

$result = implode(", ", $colors);
echo $result;
?>

🔷 explode() Function

<?php
$text = "Apple,Banana,Mango";

$arr = explode(",", $text);

print_r($arr);
?>

🔷 array_search() Function

<?php
$fruits = ["Apple", "Banana", "Mango"];

$index = array_search("Banana", $fruits);
echo $index;
?>

🔸 Associative Example
<?php
$data = [
    "a" => "Red",
    "b" => "Green",
    "c" => "Blue"
];

$key = array_search("Green", $data);
echo $key;
?>

🔷 Multidimensional Array

<?php
$students = [
    ["Priya", 22],
    ["Ravi", 24],
    ["Anu", 21]
];

echo $students[1][0]; // Ravi
echo $students[2][1]; // 21
?>