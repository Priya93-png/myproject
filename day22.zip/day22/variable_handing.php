🔹 1. boolval()
<?php
$a = 1;
$b = boolval($a);

var_dump($b);
?>

🔹 2. intval()
<?php
$a = "25";
$b = intval($a);

echo $b;
?>

🔹 3. floatval()
<?php
$a = "10.75";
$b = floatval($a);

var_dump($b);
?>

🔹 4. doubleval()
<?php
$a = "5.5";
$b = doubleval($a);

var_dump($b);
?>

🔹 5. is_bool()
<?php
$a = true;

var_dump(is_bool($a));
?>

🔹 6. is_array()
<?php
$arr = [1, 2, 3];

var_dump(is_array($arr));
?>

🔹 7. is_double()
<?php
$a = 10.5;

var_dump(is_double($a));
?>

🔹 8. is_int()
<?php
$a = 10;

var_dump(is_int($a));
?>

🔹 9. is_integer()
<?php
$a = 10;

var_dump(is_integer($a));
?>

🔹 10. is_float()
<?php
$a = 10.5;

var_dump(is_float($a));
?>

🔹 11. is_null()
<?php
$a = null;

var_dump(is_null($a));
?>

🔹 12. is_numeric()
<?php
$a = "123";

var_dump(is_numeric($a));
?>

🔹 13. is_object()
<?php
class Test {}

$obj = new Test();

var_dump(is_object($obj));
?>

14.settype() Method
<?php
$a = "50";

settype($a, "integer");

var_dump($a);
?>
