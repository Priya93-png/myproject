🔹 1. count() 
<?php
$fruits = ["Apple", "Banana", "Mango"];
echo count($fruits);
?>

🔹 2. array_push() 
<?php
$colors = ["Red", "Green"];
array_push($colors, "Blue");
print_r($colors);
?>
🔹 3. array_pop() 
<?php
$colors = ["Red", "Green", "Blue"];
array_pop($colors);
print_r($colors);
?>

🔹 4. array_shift() 
<?php
$nums = [10, 20, 30];
array_shift($nums);
print_r($nums);
?>

🔹 5. array_unshift() 
<?php
$nums = [20, 30];
array_unshift($nums, 10);
print_r($nums);
?>

🔹 6. in_array() 
<?php
$fruits = ["Apple", "Banana", "Mango"];

if (in_array("Banana", $fruits)) {
    echo "Found";
} else {
    echo "Not Found";
}
?>
🔹 7. array_slice() 
<?php
$nums = [10, 20, 30, 40, 50];
print_r(array_slice($nums, 1, 3));
?>
