<?php
include "db.php";
$sql="update student_detail set student_name='madhan',
age=25,mobile_number='987654321',city='maxico' where roll_no=9";
$result=mysqli_query($conn,$sql);
if($result)
    {
        echo "data updated";
    }
    else{
        echo "not worked";
    }
?>