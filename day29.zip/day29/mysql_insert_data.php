<?php
include("db.php");
$sql="insert into student_detail value('','pradeep',26,'9988776655','london')";

$result=mysqli_query($conn,$sql);

if($result){
    echo "data inserted";
}
else {
    echo "not insert";
}

?>