<?php
include("db.php");
$sql="select * from student_detail";
$result=mysqli_query($conn,$sql);
//print_r($result);
while($row=mysqli_fetch_assoc($result)){
print_r($row);
echo $row['age']
." ". $row['name']
."".$row['mobile']
." ".$row["city"]."<br>";
}
/*$row=mysqli_fetch_assoc($result);
print_r($row);

$row=mysqli_fetch_array($result);
print_r($row);*/

/*$row=mysqli_fetch_row($result);
print_r($row);*/

/*$row=mysqli_fetch_all($result);
print_r($row);*/

mysqli_close($conn)
?>