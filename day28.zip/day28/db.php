<?php
$conn=mysqli_connect("localhost","root","Priya@1993","stud");

if(!$conn){
die("connection Failed:" .mysqli_connect_error());
}
?>