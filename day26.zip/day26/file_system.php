<?php
mkdir("image");//create a new directory
rmdir("image");//remove a directory
rename("image","image");//rename a directory
if(is_dir("image")){
    echo "there";
}
else{
    echo "not there";
}
if(file_exists("image")){
    echo "there";
} 
else{
    echo "not there";
}

$file=fopen("text.txt","w")//r,w,a,x,r+ modes
fwrite($file,"hello,how are you");//remove old value and add write mode if
fclose($file);
echo file_get_contents("text.txt");//display file text
file_put_contents("text.txt","welcome");//remove old value and add write
copy("text.txt","target.txt");//copy the file
rename("target.txt","test1.txt");//rename target.txt to test1.txt
unlink("1111.txt");//
//delete("11112.txt");

//mail(to,subject,message,header);