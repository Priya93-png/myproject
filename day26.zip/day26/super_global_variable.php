<?php
/*echo $_SERVER["PATH"];echo "<br>";
//print_r($_SERVER);*/

session_start();
$_SESSION["id"]=345;
echo $_SESSION["id"];

/* unset($_SESSION["id"]);
echo $_SESSION["id"];*/
//header("location:form_validation.php?ids=45");//redirect
setcookie("fid","678",time()+20,"/");
$cid=$_COOKIE["fid"]
echo($cid);
$a=70;
$b=10;
while($a==70)
    {
        echo $a;
        break;
    }
function add(){
    global $a;//echo
    $c=$GLOBALS["a"]+$GLOBALS["b"];
    echo $c;
    echo $a;

}
echo $a;
add();
//print_r($_SERVER);

?>