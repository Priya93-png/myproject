Arithmetic Operators

<?php
$a = 10;
$b = 3;

echo $a + $b; // Addition
echo "<br>";
echo $a - $b; // Subtraction
echo "<br>";
echo $a * $b; // Multiplication
echo "<br>";
echo $a / $b; // Division
echo "<br>";
echo $a % $b; // Modulus
?>

Assignment Operator

<?php
$x = 5;
$x += 3; // same as x = x + 3
echo $x;
?>

Comparison Operators

<?php
$a = 10;
$b = "10";

var_dump($a == $b);
echo "<br>";
var_dump($a === $b);
?>

Logical Operators

<?php
$age = 20;

if ($age > 18 && $age < 60) {
    echo "Eligible";
}
?>

 Increment / Decrement

<?php
$x = 5;

echo ++$x; // pre-increment
echo "<br>";
echo $x--; // post-decrement
?>