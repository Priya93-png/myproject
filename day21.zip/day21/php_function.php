Simple Function Example

<?php
function sayHello() {
    echo "Hello World!";
}

sayHello(); // function call
?>

Function with Parameters

<?php
function greet($name) {
    echo "Hello " . $name;
}

greet("Priya");
?>

Function with Return Value

<?php
function add($a, $b) {
    return $a + $b;
}

$result = add(5, 3);
echo $result;
?>

Default Parameter Function

<?php
function welcome($name = "Guest") {
    echo "Welcome " . $name;
}

welcome();        // Guest
welcome("Priya"); // Priya
?>

Real-Time Example  (Area of Rectangle)
<?php
function areaRectangle($length, $width) {
    return $length * $width;
}

echo "Area = " . areaRectangle(10, 5);
?>

