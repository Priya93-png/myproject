1. strlen() — String Length

<?php
$str = "Hello";
echo strlen($str);
?>

 2. str_word_count() — Count Wo

<?php
$str = "Hello world";
echo str_word_count($str);
?>

3. strrev() — Reverse String

<?php
echo strrev("Hello");
?>

4. strpos() — Find Position

<?php
echo strpos("Hello world", "world");
?>

5. str_replace() — Replace Text

<?php
echo str_replace("world", "PHP", "Hello world");
?>

6. strtoupper() — Uppercase

<?php
echo strtoupper("hello");
?>

7. strtolower() — Lowercase

<?php
echo strtolower("HELLO");
?>

8. ucfirst() — First Letter Capital

<?php
echo ucfirst("php");
?>

9. ucwords() — Capitalize Each Word

<?php
echo ucwords("hello world");
?>


10. trim() — Remove Spaces

<?php
echo trim("  hello  ");
?>


