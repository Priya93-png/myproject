<?php

$conn = new mysqli("localhost","root","Priya@1993","student_db");

if($conn->connect_error){
    die("Connection failed");
}

$data = json_decode(file_get_contents("php://input"), true);

$name = $data['name'];
$email = $data['email'];
$age = $data['age'];

$sql = "INSERT INTO students (name,email,age) 
VALUES ('$name','$email','$age')";

if($conn->query($sql) === TRUE){
    echo json_encode(["message"=>"Data inserted successfully"]);
}
else{
    echo json_encode(["message"=>"Error inserting data"]);
}

$conn->close();

?>