<?php

$conn = mysqli_connect("localhost","root","Priya@1993","student");

$data = json_decode(file_get_contents("php://input"), true);

$id = $data['id'];
$name = $data['name'];

$sql = "UPDATE student SET name='$name' WHERE id='$id'";

if(mysqli_query($conn,$sql)){
    echo json_encode(["message"=>"Data Updated Successfully"]);
}else{
    echo json_encode(["message"=>"Update Failed"]);
}

?>